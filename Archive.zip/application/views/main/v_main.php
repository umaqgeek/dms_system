<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <center>
            
            <div class="col-md-4 " style=" border-radius: 5px; border: 2px solid #FFF; padding: 20px 20px 20px; ">
                <a href="<?=site_url('main/login'); ?>" style="text-decoration:none">
                    <div class="shadow" style=" border-radius: 5px; border: 1px solid #ccc;  padding: 10px;  ">
                        <center>
                            <img src="<?=base_url(); ?>assets/img/login.png" width="80px" height="80px">  
                            <div>Login Page</div>
                        </center>  
                    </div>
                </a>
            </div>
            
            <div class="col-md-4 " style=" border-radius: 5px; border: 2px solid #FFF; padding: 20px 20px 20px; ">
                <a href="<?=site_url('main/registration'); ?>" style="text-decoration:none">
                    <div class="shadow" style=" border-radius: 5px; border: 1px solid #ccc;  padding: 10px;  ">
                        <center>
                            <img src="<?=base_url(); ?>assets/img/register.jpg" width="80px" height="80px">  
                            <div>Registration</div>
                        </center>  
                    </div>
                </a>
            </div>
            
            <div class="col-md-4 " style=" border-radius: 5px; border: 2px solid #FFF; padding: 20px 20px 20px; ">
                <a href="<?=site_url('main/listDocuments'); ?>" style="text-decoration:none">
                    <div class="shadow" style=" border-radius: 5px; border: 1px solid #ccc;  padding: 10px;  ">
                        <center>
                            <img src="<?=base_url(); ?>assets/img/public_doc.png" width="80px" height="80px">  
                            <div>List of Public Documents</div>
                        </center>  
                    </div>
                </a>
            </div>
            
        </center>
    </div>
</div>