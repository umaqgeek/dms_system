<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <center>
            
            <div class="col-md-6 " style=" border-radius: 5px; border: 2px solid #FFF; padding: 20px 20px 20px; ">
                <a href="<?=site_url('users/publicDocument'); ?>" style="text-decoration:none">
                    <div class="shadow" style=" border-radius: 5px; border: 1px solid #ccc;  padding: 10px;  ">
                        <center>
                            <img src="<?=base_url(); ?>assets/img/public_doc.png" width="80px" height="80px">  
                            <div>Public Documents</div>
                        </center>  
                    </div>
                </a>
            </div>
            
            <div class="col-md-6 " style=" border-radius: 5px; border: 2px solid #FFF; padding: 20px 20px 20px; ">
                <a href="<?=site_url('users/privateDocument'); ?>" style="text-decoration:none">
                    <div class="shadow" style=" border-radius: 5px; border: 1px solid #ccc;  padding: 10px;  ">
                        <center>
                            <img src="<?=base_url(); ?>assets/img/private_doc.png" width="80px" height="80px">  
                            <div>My Documents</div>
                        </center>  
                    </div>
                </a>
            </div>
            
        </center>
    </div>
</div>